from django.forms import Form, CharField, Textarea, PasswordInput, DateField, Select, ChoiceField, RadioSelect
from django.forms.extras.widgets import SelectDateWidget


class UserPostForm(Form):
    text = CharField(widget=Textarea(
        attrs={'rows': 3, 'cols': 40, 'placeholder': "What's on your mind?", 'class': "form-control"}))


class UserPostCommentForm(Form):
    text = CharField(widget=Textarea(
        attrs={'rows': 2, 'cols': 50, 'placeholder': "Write a comment...", 'class':"form-control"}))


class UserLogin(Form):
    username = CharField(max_length=30)
    password = CharField(widget=PasswordInput)


class EditForm(Form):
    surname = CharField(max_length=30)
    name = CharField(max_length=30)
    birthdate = DateField(widget=SelectDateWidget)
    sex_choices = (
        ('M', 'Male'),
        ('F', 'Female'),
    )
    sex = ChoiceField(widget=RadioSelect, choices=sex_choices)