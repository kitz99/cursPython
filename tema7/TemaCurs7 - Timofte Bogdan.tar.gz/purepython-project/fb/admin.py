from django.contrib import admin

from fb.models import UserPost
from fb.models import UserProfile


admin.site.register(UserPost)
admin.site.register(UserProfile)
