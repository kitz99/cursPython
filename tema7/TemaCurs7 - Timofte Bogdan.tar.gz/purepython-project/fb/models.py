from django.db import models
from django.contrib.auth.models import User


class UserPost(models.Model):
    text = models.TextField(max_length=200)
    date_added = models.DateTimeField(auto_now_add=True)

    author = models.ForeignKey(User)

    def __unicode__(self):
        return '{} @ {}'.format(self.author, self.date_added)

    class Meta:
        ordering = ['-date_added']


class UserPostComment(models.Model):
    text = models.TextField(max_length=100)
    date_added = models.DateTimeField(auto_now_add=True)

    author = models.ForeignKey(User)
    post = models.ForeignKey(UserPost)

    def __unicode__(self):
        return '{} @ {}'.format(self.author, self.date_added)

    class Meta:
        ordering = ['date_added']


class UserProfile(models.Model):
    username = models.OneToOneField(User, primary_key=True)
    surname = models.TextField(max_length=50)
    name = models.TextField(max_length=50)
    birthdate = models.DateField()
    sex_choices = (
        ('M', 'Male'),
        ('F', 'Female'),
    )
    sex = models.CharField(max_length=2, choices=sex_choices, default='M')
    avatar = models.ImageField(upload_to='avatars')

    def __unicode__(self):
        return 'Profile of {} ---> {} {}'.format(self.username, self.name, self.surname)




