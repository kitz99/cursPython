from django.core.urlresolvers import reverse
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required

from fb.models import UserPost, UserPostComment, UserProfile
from fb.forms import UserPostForm, UserPostCommentForm, UserLogin, EditForm
from datetime import date


@login_required
def index(request):
    posts = UserPost.objects.all()
    if request.method == 'GET':
        form = UserPostForm()
    elif request.method == 'POST':
        form = UserPostForm(request.POST)
        if form.is_valid():
            text = form.cleaned_data['text']
            post = UserPost(text=text, author=request.user)
            post.save()

    context = {
        'posts': posts,
        'form': form,
    }
    return render(request, 'index.html', context)


@login_required
def post_details(request, pk):
    post = UserPost.objects.get(pk=pk)

    if request.method == 'GET':
        form = UserPostCommentForm()
    elif request.method == 'POST':
        form = UserPostCommentForm(request.POST)
        if form.is_valid():
            cleaned_data = form.cleaned_data
            comment = UserPostComment(text=cleaned_data['text'],
                                      post=post,
                                      author=request.user)
            comment.save()

    comments = UserPostComment.objects.filter(post=post)

    context = {
        'post': post,
        'comments': comments,
        'form': form,
    }

    return render(request, 'post_details.html', context)


def login_view(request):
    if request.method == 'GET':
        login_form = UserLogin()
        context = {
            'form': login_form,
        }
        return render(request, 'login.html', context)
    if request.method == 'POST':
        login_form = UserLogin(request.POST)
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('/')
        else:
            context = {
                'form': login_form,
                'message': 'Wrong user and/or password!',
            }
            return render(request, 'login.html', context)


def logout_view(request):
    logout(request)
    return redirect(reverse('login'))


def view_profile(request, pk):
    user = UserProfile.objects.get(pk=pk)
    if request.method == 'GET':
        context = {
            'userProfile': user
        }
        return render(request, 'user_profile.html', context)


def edit_profile(request, pk):
    user = UserProfile.objects.get(pk=pk)
    if request.method == 'GET':
        edit_form = EditForm()
        context = {
            'form': edit_form,
            'user': user
        }
        return render(request, 'edit_profile.html', context)
    if request.method == 'POST':
        surname = request.POST['surname']
        name = request.POST['name']
        birthdate = date(int(request.POST["birthdate_year"]), int(request.POST["birthdate_month"]), int(request.POST["birthdate_day"]))
        sex = request.POST["sex"]

        if surname is not None:
            user.surname = surname

        if name is not None:
            user.name = name

        if birthdate is not None:
            user.birthdate = birthdate

        if sex is not None:
            user.sex = sex
        user.save()
        context = {
            'user': user
        }
        # return render(request, 'user_profile.html', context)
        return redirect('/profile/' + str(user.pk))

